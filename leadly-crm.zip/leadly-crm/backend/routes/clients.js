const express = require('express');
const router = express.Router();
const db = require('../config/db');

router.get('/', (req, res) => {
  db.query('SELECT * FROM clients ORDER BY created_at DESC', (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

router.get('/:id', (req, res) => {
  db.query(
    'SELECT * FROM clients WHERE id = ?',
    [req.params.id],
    (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      if (results.length === 0) {
        return res.status(404).json({ error: 'Client not found' });
      }
      res.json(results[0]);
    }
  );
});

router.post('/', (req, res) => {
  const { name, email, phone, company, latitude, longitude, h3_index } = req.body;

  db.query(
    'INSERT INTO clients (name, email, phone, company, latitude, longitude, h3_index) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [name, email, phone, company, latitude, longitude, h3_index],
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json({ message: 'Client added successfully', id: result.insertId });
    }
  );
});

router.put('/:id', (req, res) => {
  const { name, email, phone, company, latitude, longitude, h3_index } = req.body;

  db.query(
    'UPDATE clients SET name = ?, email = ?, phone = ?, company = ?, latitude = ?, longitude = ?, h3_index = ? WHERE id = ?',
    [name, email, phone, company, latitude, longitude, h3_index, req.params.id],
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'Client not found' });
      }
      res.json({ message: 'Client updated successfully' });
    }
  );
});

const { requireAdmin } = require('../middleware/auth');

router.delete('/:id', requireAdmin, (req, res) => {
  db.query(
    'DELETE FROM clients WHERE id = ?',
    [req.params.id],
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'Client not found' });
      }
      res.json({ message: 'Client deleted successfully' });
    }
  );
});

module.exports = router;
