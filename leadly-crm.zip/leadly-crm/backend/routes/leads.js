const express = require('express');
const router = express.Router();
const db = require('../config/db');

router.get('/', (req, res) => {
  const query = `
    SELECT leads.*, clients.name as client_name, clients.email as client_email
    FROM leads
    LEFT JOIN clients ON leads.client_id = clients.id
    ORDER BY leads.created_at DESC
  `;
  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

router.get('/:id', (req, res) => {
  db.query(
    'SELECT * FROM leads WHERE id = ?',
    [req.params.id],
    (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      if (results.length === 0) {
        return res.status(404).json({ error: 'Lead not found' });
      }
      res.json(results[0]);
    }
  );
});

router.post('/', (req, res) => {
  const { client_id, status, source, notes } = req.body;

  db.query(
    'INSERT INTO leads (client_id, status, source, notes) VALUES (?, ?, ?, ?)',
    [client_id, status || 'New', source, notes],
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json({ message: 'Lead created successfully', id: result.insertId });
    }
  );
});

router.put('/:id', (req, res) => {
  const { client_id, status, source, notes } = req.body;

  db.query(
    'UPDATE leads SET client_id = ?, status = ?, source = ?, notes = ? WHERE id = ?',
    [client_id, status, source, notes, req.params.id],
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'Lead not found' });
      }
      res.json({ message: 'Lead updated successfully' });
    }
  );
});

router.delete('/:id', (req, res) => {
  db.query(
    'DELETE FROM leads WHERE id = ?',
    [req.params.id],
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'Lead not found' });
      }
      res.json({ message: 'Lead deleted successfully' });
    }
  );
});

module.exports = router;
