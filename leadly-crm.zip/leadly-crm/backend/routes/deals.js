const express = require('express');
const router = express.Router();
const db = require('../config/db');
const fs = require('fs');

//  CACHE 
let dealsCache = null;

//  LOGGING 
function logAction(action) {
  const log = `[${new Date().toISOString()}] ${action}\n`;
  fs.appendFileSync('log.txt', log);
}

//  WORKFLOW 
const validTransitions = {
  Pending: ['Won', 'Lost'],
  Won: [],
  Lost: []
};

//  GET ALL DEALS 
router.get('/', (req, res) => {
  if (dealsCache) {
    console.log('📦 From cache');
    return res.json(dealsCache);
  }

  const query = `
    SELECT deals.*, leads.status as lead_status, clients.name as client_name
    FROM deals
    LEFT JOIN leads ON deals.lead_id = leads.id
    LEFT JOIN clients ON leads.client_id = clients.id
    ORDER BY deals.created_at DESC
  `;

  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    dealsCache = results; 
    console.log('💾 From DB');

    res.json(results);
  });
});

//  GET STATS 
router.get('/stats', (req, res) => {
  const query = `
    SELECT
      COUNT(*) as total_deals,
      SUM(amount) as total_amount,
      AVG(amount) as avg_amount,
      SUM(CASE WHEN status = 'Won' THEN amount ELSE 0 END) as won_amount,
      SUM(CASE WHEN status = 'Lost' THEN amount ELSE 0 END) as lost_amount
    FROM deals
  `;

  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results[0]);
  });
});

//  CREATE DEAL 
router.post('/', (req, res) => {
  const { lead_id, amount, status, description } = req.body;

  db.query(
    'INSERT INTO deals (lead_id, amount, status, description, created_at) VALUES (?, ?, ?, ?, NOW())',
    [lead_id, amount, status || 'Pending', description],
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }

      dealsCache = null; 
      logAction(`Deal created ID=${result.insertId}`);

      res.json({ message: 'Deal created successfully', id: result.insertId });
    }
  );
});

//  UPDATE DEAL (ВАЖНО) 
router.put('/:id', (req, res) => {
  const { lead_id, amount, status, description } = req.body;

  db.query(
    'SELECT status FROM deals WHERE id = ?',
    [req.params.id],
    (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      if (results.length === 0) {
        return res.status(404).json({ error: 'Deal not found' });
      }

      const currentStatus = results[0].status;

      if (!validTransitions[currentStatus].includes(status)) {
        return res.status(400).json({
          error: `Invalid transition: ${currentStatus} → ${status}`
        });
      }

      db.query(
        'UPDATE deals SET lead_id = ?, amount = ?, status = ?, description = ?, updated_at = NOW() WHERE id = ?',
        [lead_id, amount, status, description, req.params.id],
        (err, result) => {
          if (err) return res.status(500).json({ error: err.message });

          dealsCache = null; // сброс cache
          logAction(`Deal ${req.params.id} updated to ${status}`);

          res.json({ message: 'Deal updated successfully' });
        }
      );
    }
  );
});

//  DELETE 
router.delete('/:id', (req, res) => {
  db.query(
    'DELETE FROM deals WHERE id = ?',
    [req.params.id],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });

      dealsCache = null;
      logAction(`Deal ${req.params.id} deleted`);

      res.json({ message: 'Deal deleted successfully' });
    }
  );
});

module.exports = router;