const express = require('express');
const router = express.Router();
const db = require('../config/db');

router.get('/', (req, res) => {
  const query = `
    SELECT activities.*, clients.name as client_name
    FROM activities
    LEFT JOIN clients ON activities.client_id = clients.id
    ORDER BY activities.created_at DESC
    LIMIT 50
  `;
  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

router.get('/client/:clientId', (req, res) => {
  db.query(
    'SELECT * FROM activities WHERE client_id = ? ORDER BY created_at DESC',
    [req.params.clientId],
    (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json(results);
    }
  );
});

router.post('/', (req, res) => {
  const { client_id, note, activity_type } = req.body;

  db.query(
    'INSERT INTO activities (client_id, note, activity_type) VALUES (?, ?, ?)',
    [client_id, note, activity_type || 'Note'],
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json({ message: 'Activity added successfully', id: result.insertId });
    }
  );
});

module.exports = router;
