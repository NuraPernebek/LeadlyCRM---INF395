const express = require('express');
const router = express.Router();
const db = require('../config/db');

router.get('/', (req, res) => {
  const query = `
    SELECT tickets.*, clients.name as client_name
    FROM tickets
    LEFT JOIN clients ON tickets.client_id = clients.id
    ORDER BY tickets.created_at DESC
  `;
  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

router.post('/', (req, res) => {
  const { client_id, message, status } = req.body;

  db.query(
    'INSERT INTO tickets (client_id, message, status) VALUES (?, ?, ?)',
    [client_id, message, status || 'Open'],
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json({ message: 'Ticket created successfully', id: result.insertId });
    }
  );
});

router.put('/:id', (req, res) => {
  const { status } = req.body;

  db.query(
    'UPDATE tickets SET status = ? WHERE id = ?',
    [status, req.params.id],
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json({ message: 'Ticket updated successfully' });
    }
  );
});

module.exports = router;
