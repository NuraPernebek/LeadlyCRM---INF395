const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());


const authRoutes = require('./routes/auth');
const clientRoutes = require('./routes/clients');
const leadRoutes = require('./routes/leads');
const dealRoutes = require('./routes/deals');
const ticketRoutes = require('./routes/tickets');
const activityRoutes = require('./routes/activities');

app.use('/api/auth', authRoutes);
app.use('/api/clients', clientRoutes);
app.use('/api/leads', leadRoutes);
app.use('/api/deals', dealRoutes);
app.use('/api/tickets', ticketRoutes);
app.use('/api/activities', activityRoutes);

app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'Leadly CRM API is running' });
});

const PORT = process.env.PORT || 5002;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
