CREATE DATABASE IF NOT EXISTS leadly_crm CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE leadly_crm;

-- Таблица пользователей
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Таблица клиентов
CREATE TABLE IF NOT EXISTS clients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(50),
    company VARCHAR(255),
    latitude FLOAT,
    longitude FLOAT,
    h3_index VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Таблица лидов
CREATE TABLE IF NOT EXISTS leads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT NOT NULL,
    status VARCHAR(50) DEFAULT 'New',
    source VARCHAR(255),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
);

-- Таблица сделок
CREATE TABLE IF NOT EXISTS deals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lead_id INT NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'Pending',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE
);

-- Таблица тикетов поддержки
CREATE TABLE IF NOT EXISTS tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT NOT NULL,
    message TEXT NOT NULL,
    status VARCHAR(50) DEFAULT 'Open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
);

-- Таблица активностей/заметок
CREATE TABLE IF NOT EXISTS activities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT NOT NULL,
    note TEXT NOT NULL,
    activity_type VARCHAR(50) DEFAULT 'Note',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
);

-- Таблица аудит-логов
CREATE TABLE IF NOT EXISTS audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action TEXT NOT NULL,
    table_name VARCHAR(100),
    record_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Демо-данные

-- Добавление тестового пользователя (пароль: admin)
INSERT INTO users (email, password, role) VALUES
('admin@leadly.com', 'admin', 'admin'),
('manager@leadly.com', 'manager', 'manager');

-- Добавление демо-клиентов
INSERT INTO clients (name, email, phone, company) VALUES
('Иван Петров', 'ivan@example.com', '+7 900 123-45-67', 'ООО Техно'),
('Мария Сидорова', 'maria@example.com', '+7 901 234-56-78', 'ИП Сидорова'),
('Алексей Иванов', 'alex@example.com', '+7 902 345-67-89', 'ЗАО Инновации'),
('Елена Козлова', 'elena@example.com', '+7 903 456-78-90', 'ООО Медиа'),
('Дмитрий Соколов', 'dmitry@example.com', '+7 904 567-89-01', 'ИП Соколов');

-- Добавление демо-лидов
INSERT INTO leads (client_id, status, source, notes) VALUES
(1, 'New', 'Website', 'Интересуется продуктом А'),
(2, 'Contacted', 'Referral', 'Перезвонить в пятницу'),
(3, 'Qualified', 'Advertisement', 'Готов к покупке'),
(4, 'New', 'Social Media', 'Запросил презентацию'),
(5, 'Contacted', 'Email Campaign', 'Обсудили условия');

-- Добавление демо-сделок
INSERT INTO deals (lead_id, amount, status, description) VALUES
(1, 150000.00, 'Pending', 'Сделка на внедрение'),
(2, 75000.00, 'Won', 'Подписан договор'),
(3, 200000.00, 'Won', 'Крупная сделка'),
(4, 50000.00, 'Pending', 'Ожидает решения'),
(5, 120000.00, 'Lost', 'Отказался');

-- Добавление демо-тикетов
INSERT INTO tickets (client_id, message, status) VALUES
(1, 'Не работает вход в систему', 'Open'),
(2, 'Вопрос по тарифам', 'Closed'),
(3, 'Запрос на демо', 'Open');

-- Добавление демо-активностей
INSERT INTO activities (client_id, note, activity_type) VALUES
(1, 'Первый контакт по телефону', 'Call'),
(2, 'Отправлено коммерческое предложение', 'Email'),
(3, 'Проведена демонстрация продукта', 'Meeting'),
(4, 'Получен запрос на консультацию', 'Note'),
(5, 'Обсуждение условий договора', 'Call');

-- Создание индексов для оптимизации
CREATE INDEX idx_clients_email ON clients(email);
CREATE INDEX idx_leads_client_id ON leads(client_id);
CREATE INDEX idx_leads_status ON leads(status);
CREATE INDEX idx_deals_lead_id ON deals(lead_id);
CREATE INDEX idx_deals_status ON deals(status);
CREATE INDEX idx_tickets_client_id ON tickets(client_id);
CREATE INDEX idx_activities_client_id ON activities(client_id);
