# Leadly CRM

Полнофункциональная CRM-система для управления клиентами, лидами и сделками.

## 🚀 Быстрый старт

### Требования

- Node.js 14+
- MySQL 5.7+

### 1. Настройка базы данных

```bash
# Войдите в MySQL
mysql -u root -p

# Импортируйте базу данных
source database.sql
```

Или выполните SQL-скрипт через phpMyAdmin/MySQL Workbench.

### 2. Запуск Backend

```bash
cd backend
npm install
npm start
```

Сервер запустится на `http://localhost:5000`

### 3. Запуск Frontend

Просто откройте файл `frontend/index.html` в браузере или используйте live-server:

```bash
cd frontend
npx live-server
```

## 📁 Структура проекта

```
leadly-crm/
├── backend/
│   ├── server.js          # Главный файл сервера
│   ├── package.json       # Зависимости
│   ├── config/
│   │   └── db.js          # Подключение к БД
│   └── routes/
│       ├── auth.js        # Авторизация
│       ├── clients.js     # API клиентов
│       ├── leads.js       # API лидов
│       ├── deals.js       # API сделок
│       ├── tickets.js     # API тикетов
│       └── activities.js  # API активностей
├── frontend/
│   ├── index.html         # Страница входа
│   ├── dashboard.html     # Главная панель
│   ├── clients.html       # Управление клиентами
│   ├── leads.html         # Управление лидами
│   ├── deals.html         # Управление сделками
│   ├── analytics.html     # Аналитика
│   ├── css/
│   │   └── style.css      # Стили
│   └── js/
│       └── app.js         # Общие функции
└── database.sql           # Структура БД
```

## ✅ Функционал

### Реализовано:

- 🔐 **Авторизация JWT** - безопасная аутентификация
- 👤 **Клиенты** - полный CRUD (создание, чтение, обновление, удаление)
- 🎯 **Лиды** - управление лидами с разными статусами
- 💰 **Сделки** - отслеживание сделок и сумм
- 📊 **Аналитика** - графики и статистика (Chart.js)
- 🎫 **Тикеты** - система поддержки клиентов
- 📝 **Активности** - история взаимодействий
- 📱 **Адаптивный дизайн** - работает на всех устройствах

### API Endpoints:

| Метод | Endpoint | Описание |
|-------|----------|----------|
| POST | /api/auth/login | Вход в систему |
| POST | /api/auth/register | Регистрация |
| GET | /api/clients | Список клиентов |
| POST | /api/clients | Создать клиента |
| PUT | /api/clients/:id | Обновить клиента |
| DELETE | /api/clients/:id | Удалить клиента |
| GET | /api/leads | Список лидов |
| POST | /api/leads | Создать лид |
| PUT | /api/leads/:id | Обновить лид |
| DELETE | /api/leads/:id | Удалить лид |
| GET | /api/deals | Список сделок |
| GET | /api/deals/stats | Статистика сделок |
| POST | /api/deals | Создать сделку |
| PUT | /api/deals/:id | Обновить сделку |
| DELETE | /api/deals/:id | Удалить сделку |

## 🔑 Демо-данные

После импорта базы данных доступны тестовые пользователи:

| Email | Пароль | Роль |
|-------|--------|------|
| admin@leadly.com | admin | Администратор |
| manager@leadly.com | manager | Менеджер |

Также созданы 5 демо-клиентов, 5 лидов и 5 сделок для тестирования.

## ⚙️ Конфигурация

### Переменные окружения (backend/.env):

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=
DB_NAME=leadly_crm
JWT_SECRET=your-secret-key
PORT=5000
```

### Настройка подключения к БД:

Отредактируйте `backend/config/db.js`:

```javascript
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'leadly_crm'
});
```

## 🛠️ Разработка

### Установка зависимостей backend:

```bash
cd backend
npm install
```

### Запуск в режиме разработки:

```bash
npm run dev  # с nodemon
```

## 📸 Скриншоты

- **Login** - Красивая страница входа с градиентом
- **Dashboard** - Статистика и последние данные
- **Clients** - Таблица клиентов с CRUD
- **Leads** - Управление лидами
- **Deals** - Управление сделками
- **Analytics** - Графики и аналитика

## 📝 Лицензия

MIT License
